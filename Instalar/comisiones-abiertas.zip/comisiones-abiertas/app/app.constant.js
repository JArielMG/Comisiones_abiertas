myApp.constant('config', {
   restUrl: "http://172.20.32.34:9080/ViajesClaros/webresources/" 
});
